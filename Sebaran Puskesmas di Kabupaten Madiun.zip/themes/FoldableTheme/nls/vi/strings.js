define({
  "_themeLabel": "Chủ đề Có thể gấp được",
  "_layout_default": "Bố cục mặc định",
  "_layout_layout1": "Bố cục 1"
});